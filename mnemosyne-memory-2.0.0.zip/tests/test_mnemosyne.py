#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mnemosyne v2.0.0 Self-Test Suite (zero-dependency, unittest)
Run: python -m unittest discover -s tests -v
   or: python tests/test_mnemosyne.py -v
"""

import json
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
import mnemosyne as M


class TestMemoryBrain(unittest.TestCase):
    """MemoryBrain 认知中枢测试。"""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="mnemo2-test-")
        self.brain = M.MemoryBrain(self.tmp, enable_embeddings=True, enable_graph=True)
        self.brain.ensure_init()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_init_creates_files(self):
        self.assertTrue(os.path.exists(self.brain.store.index_path))
        self.assertTrue(os.path.exists(self.brain.store.meta_path))
        meta = self.brain.store.read_meta()
        self.assertEqual(meta["schema"], "mnemosyne-v2")

    def test_retain_with_auto_extraction(self):
        rec = self.brain.retain("Alice works at Acme as chief engineer since 2024-03-15.", mtype="semantic")
        self.assertIsNotNone(rec["id"])
        self.assertEqual(rec["fact_type"], "fact")
        self.assertIn("Alice", rec["entities"])
        self.assertIn("Acme", rec["entities"])
        self.assertEqual(rec["event_time"], "2024-03-15T00:00:00")
        self.assertGreater(rec["confidence"], 0.8)
        self.assertEqual(rec["source_type"], "user")

    def test_retain_opinion_type(self):
        rec = self.brain.retain("堃哥偏好结论先行的回答风格，回答必须简短。", mtype="preference")
        self.assertEqual(rec["fact_type"], "opinion")
        self.assertEqual(rec["importance"], 5)

    def test_retain_belief_type(self):
        rec = self.brain.retain("我认为个人 AI 记忆系统应优先本地化、零依赖。", mtype="belief")
        self.assertEqual(rec["fact_type"], "belief")
        self.assertEqual(rec["layer"], "reflective")

    def test_retain_with_confidence(self):
        rec = self.brain.retain("test", mtype="semantic", confidence=0.85)
        self.assertEqual(rec["confidence"], 0.85)

    def test_embedding_generated(self):
        rec = self.brain.retain("Embedding test content for vector search.", mtype="semantic")
        self.assertIsNotNone(rec.get("embedding"))
        self.assertEqual(len(rec["embedding"]), M.EMBEDDING_DIM)

    def test_graph_edges_created(self):
        rec = self.brain.retain("Alice 是 Acme 公司的首席工程师，负责 AI 平台架构。", mtype="semantic")
        edges = rec.get("graph_edges", [])
        self.assertGreater(len(edges), 0)

    def test_graph_query(self):
        self.brain.retain("Alice 是 Acme 公司的首席工程师。", mtype="semantic")
        neighbors = self.brain.graph_query("Alice", depth=2)
        self.assertIn("Alice", neighbors.get("depth_0", []))

    def test_graph_path(self):
        self.brain.retain("Alice 是 Acme 的工程师。", mtype="semantic")
        self.brain.retain("Acme 是一家 AI 公司。", mtype="semantic")
        path = self.brain.graph_path("Alice", "Acme", max_depth=3)
        self.assertIsNotNone(path)

    def test_recall_five_way_fusion(self):
        self.brain.retain("Alice works at Acme as chief engineer.", mtype="semantic", importance=5)
        self.brain.retain("堃哥偏好结论先行的回答。", mtype="preference", importance=4)
        hits = self.brain.recall("Where does Alice work?", k=3)
        self.assertTrue(len(hits) >= 1)
        score, rec, reasons = hits[0]
        self.assertIn("Acme", rec["content"])
        self.assertTrue(len(reasons) >= 1)

    def test_recall_multi_hop(self):
        for i in range(5):
            self.brain.retain(f"项目{i}使用了模块化架构，负责人是Bob。", mtype="semantic")
        self.brain.retain("Bob是后端团队的架构师，负责微服务设计。", mtype="semantic")
        hits = self.brain.recall("模块化架构 微服务设计", k=3, multi_hop=True)
        self.assertTrue(len(hits) >= 1)

    def test_recall_with_type_filter(self):
        self.brain.retain("labor arbitration", mtype="episodic")
        self.brain.retain("general knowledge", mtype="semantic")
        hits = self.brain.recall("labor", k=5, mtype="episodic")
        self.assertTrue(all(h[1]["type"] == "episodic" for h in hits))

    def test_reflect_deep(self):
        self.brain.retain("Alice lives in Beijing.", mtype="semantic")
        self.brain.retain("Alice lives in Shanghai now.", mtype="semantic")
        self.brain.retain("堃哥偏好结论先行的回答风格。", mtype="preference")
        ref = self.brain.reflect(deep=True)
        self.assertGreaterEqual(ref["total"], 3)
        self.assertIn("confidence_stats", ref)
        self.assertIn("by_fact_type", ref)
        self.assertIn("by_verification", ref)

    def test_consolidate_dry_run(self):
        self.brain.retain("模块化架构是软件开发的最佳实践，能提高可维护性。", mtype="semantic")
        self.brain.retain("模块化设计可以大幅提升代码的可维护性和复用性。", mtype="semantic")
        self.brain.retain("采用模块化架构的好处是可维护性和可扩展性。", mtype="semantic")
        result = self.brain.consolidate(dry_run=True, min_similarity=0.3)
        self.assertGreaterEqual(result["consolidated"], 0)

    def test_self_learn(self):
        self.brain.retain("教训：不要在生产环境直接改配置。", mtype="lesson")
        self.brain.retain("偏好：代码注释用中文。", mtype="preference")
        self.brain.retain("偏好：UI用Shadcn风格。", mtype="preference")
        self.brain.retain("偏好：开源方案优先。", mtype="preference")
        result = self.brain.self_learn(lookback_days=365)
        self.assertGreaterEqual(result["learned"], 0)

    def test_backward_compat_v1(self):
        """v1.x 记录升级到 v2.0 兼容性。"""
        # 模拟 v1.x 记录（version=1，缺少v2字段）
        v1_rec = {
            "id": "test001",
            "content": "v1 style memory",
            "type": "semantic",
            "layer": "semantic",
            "version": 1,
            "created_at": "2026-01-01T00:00:00",
        }
        upgraded = M._upgrade_record(v1_rec)
        self.assertEqual(upgraded["version"], 1)
        self.assertIn("fact_type", upgraded)
        self.assertIn("confidence", upgraded)
        self.assertIn("source_type", upgraded)
        self.assertIn("event_time", upgraded)

    def test_search_capture_dedup(self):
        res1 = self.brain.search_capture("test query", "result 1", urls=["url1"])
        res2 = self.brain.search_capture("test query", "result 2", urls=["url1"])
        self.assertTrue(res2["updated"])
        self.assertEqual(res2["capture_count"], 2)

    def test_should_research_fresh(self):
        self.brain.search_capture("test query", "content", urls=["u1"])
        res = self.brain.should_research("test query", max_age_days=365)
        self.assertTrue(res["found"])
        self.assertTrue(res["fresh"])

    def test_forget_and_status(self):
        rec = self.brain.retain("to be forgotten", mtype="semantic")
        ok = self.brain.forget(rec["id"])
        self.assertTrue(ok)
        found = self.brain.store.find_by_id(rec["id"])
        self.assertEqual(found["status"], "deleted")


class TestEmbeddingEngine(unittest.TestCase):
    def setUp(self):
        self.e = M.EmbeddingEngine(dim=128, seed=42)

    def test_encode_returns_vector(self):
        v = self.e.encode("Hello world test")
        self.assertEqual(len(v), 128)
        self.assertAlmostEqual(sum(x * x for x in v), 1.0, places=1)

    def test_similarity_same_text(self):
        v1 = self.e.encode("Alice works at Acme")
        v2 = self.e.encode("Alice works at Acme")
        sim = self.e.similarity(v1, v2)
        self.assertGreater(sim, 0.95)

    def test_similarity_different_text(self):
        v1 = self.e.encode("weather is nice today")
        v2 = self.e.encode("machine learning algorithms")
        sim = self.e.similarity(v1, v2)
        self.assertLess(sim, 0.5)

    def test_encode_batch(self):
        texts = ["text one", "text two", "text three"]
        vectors = self.e.encode_batch(texts)
        self.assertEqual(len(vectors), 3)
        self.assertEqual(len(vectors[0]), 128)


class TestEntityExtraction(unittest.TestCase):
    def test_chinese_entities(self):
        ents = M._extract_entities("Alice 是 Acme 公司的首席工程师")
        names = [e["entity"] for e in ents]
        self.assertTrue(any("Alice" in n or "Acme" in n for n in names))

    def test_chinese_bigram(self):
        toks = M._tokenize("劳动仲裁流程")
        self.assertIn("劳动", toks)
        self.assertIn("仲裁", toks)

    def test_english_entities(self):
        ents = M._extract_entities("Microsoft and Google are tech giants")
        names = [e["entity"] for e in ents]
        self.assertTrue(any("Microsoft" in n or "Google" in n for n in names))

    def test_version_pattern(self):
        ents = M._extract_entities("version 2.0.0 is released")
        names = [e["entity"] for e in ents]
        self.assertTrue(any("2.0.0" in n for n in names))

    def test_relationship_extraction(self):
        text = "Alice 是 Acme 公司的首席工程师，负责 AI 平台架构。"
        entities = M._extract_entities(text)
        rels = M._extract_relationships(entities, text)
        self.assertGreater(len(rels), 0)


class TestBiTemporal(unittest.TestCase):
    def test_event_time_extraction(self):
        content = "2024-03-15 Alice joined Acme."
        et = M._extract_event_time(content, "2024-06-01T00:00:00")
        self.assertEqual(et, "2024-03-15T00:00:00")

    def test_event_time_chinese_format(self):
        content = "2024年3月15日 Alice 加入 Acme。"
        et = M._extract_event_time(content, "2024-06-01T00:00:00")
        self.assertIn("2024-03-15", et)

    def test_no_event_time(self):
        content = "Alice is an engineer."
        et = M._extract_event_time(content, "2024-06-01T00:00:00")
        self.assertEqual(et, "2024-06-01T00:00:00")


class TestConfidenceSystem(unittest.TestCase):
    def test_default_confidence_by_source(self):
        self.assertGreater(M._default_confidence("user"), 0.9)
        self.assertLess(M._default_confidence("agent_generated"), 0.5)
        self.assertGreater(M._default_confidence("file"), M._default_confidence("web_search"))

    def test_auto_importance(self):
        imp_high = M._auto_importance("密码是abc123", "semantic", [])
        imp_low = M._auto_importance("今天天气不错", "semantic", [])
        self.assertGreaterEqual(imp_high, 5)
        self.assertEqual(imp_low, 2)

    def test_importance_by_type(self):
        imp_id = M._auto_importance("test", "identity", [])
        imp_sem = M._auto_importance("test", "semantic", [])
        self.assertGreater(imp_id, imp_sem)

    def test_fact_type_inference(self):
        self.assertEqual(M._infer_fact_type("preference", "我喜欢简洁回答"), "opinion")
        self.assertEqual(M._infer_fact_type("semantic", "Alice works at Acme"), "fact")
        self.assertEqual(M._infer_fact_type("procedural", "test"), "fact")

    def test_source_type_inference(self):
        self.assertEqual(M._infer_source_type("web", None), "web_search")
        self.assertEqual(M._infer_source_type("semantic", None), "user")
        self.assertEqual(M._infer_source_type("lesson", None), "inference")


class TestDedupAndRepair(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="mnemo2-test-")
        self.brain = M.MemoryBrain(self.tmp, enable_embeddings=False, enable_graph=False)
        self.brain.ensure_init()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_dedup_exact(self):
        self.brain.retain("duplicate content here", mtype="semantic")
        self.brain.retain("duplicate content here", mtype="semantic")
        result = self.brain.dedup(dry_run=False)
        self.assertEqual(result["merged"], 1)

    def test_repair_no_corruption(self):
        self.brain.retain("good memory", mtype="semantic")
        res = self.brain.repair(dry_run=True)
        self.assertEqual(res["corrupt"], 0)

    def test_repair_actually_fixes(self):
        self.brain.retain("good memory", mtype="semantic")
        with open(self.brain.store.index_path, "a", encoding="utf-8") as f:
            f.write("{corrupt json}\n")
        res = self.brain.repair(dry_run=False)
        self.assertEqual(res["corrupt"], 1)
        self.assertEqual(res["kept"], 1)


class TestExportImport(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="mnemo2-test-")
        self.brain = M.MemoryBrain(self.tmp, enable_embeddings=False, enable_graph=False)
        self.brain.ensure_init()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_export_import_roundtrip(self):
        self.brain.retain("roundtrip memory", mtype="semantic", confidence=0.9)
        exported = self.brain.export(fmt="json")
        self.assertIn("roundtrip", exported)

        # Import to new brain
        tmp2 = tempfile.mkdtemp(prefix="mnemo2-test2-")
        try:
            brain2 = M.MemoryBrain(tmp2, enable_embeddings=False, enable_graph=False)
            brain2.ensure_init()
            path = os.path.join(tmp2, "export.json")
            with open(path, "w", encoding="utf-8") as f:
                f.write(exported)
            n = brain2.import_file(path)
            self.assertEqual(n, 1)
        finally:
            shutil.rmtree(tmp2, ignore_errors=True)


class TestHindsightsBench(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="mnemo2-test-")
        self.brain = M.MemoryBrain(self.tmp, enable_embeddings=True, enable_graph=True)
        self.brain.ensure_init()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_hindsights_bench_runs(self):
        result = M._hindsights_bench(self.brain, test_count=50)
        self.assertIn("average_score", result)
        self.assertGreater(result["average_score"], 7.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
